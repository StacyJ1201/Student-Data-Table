//
//  main.cpp
//  StudentTable
//
//  Created by Stacy Jones on 10/5/23.
//

#include "Roster.h"
#include <iostream> // Include the iostream library for cout

#ifdef _WIN32
#include <conio.h> // Include conio.h for _getch() on Windows
#else
#include <cstdlib> // Include cstdlib for system() on other platforms
#endif

int main()
{
    
    std::cout << "Submission Information: Scripting and Programming Applications, C++, 011207866, Stacy Jones";
    std::cout << std::endl;
    
    const std::string studentData[] =
    {
        "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
        "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
        "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
        "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
        "011207866,Stacy,Jones,sjo4253@wgu.edu,22,7,10,15,SOFTWARE"
    };
    const int  numStudents = 5;
    Roster roster;

    for (int i = 0; i < numStudents; i++)
        roster.parse(studentData[i]);

    std::cout << "Displaying all students: " << std::endl;
    roster.printAll();
    std::cout << std::endl;

    std::cout << "Displaying students with invalid Emails" << std::endl;
    roster.printInvalidEmails();
    std::cout << std::endl;

    std::cout << "Displaying average days" << std::endl;
    std::cout << "Format: ID | Avg" << std::endl;
    std::vector<std::string> studentIDs = {"A1", "A2", "A3", "A4", "011207866"};

    for (const std::string& studentID : studentIDs) {
        roster.printAverageDays(studentID);
    }
    std::cout << std::endl;
    
    for (int i = 0; i < 3; i++)
    {
        std::cout << "Displaying by degree: " << degreeStrings[i] << std::endl;
        roster.printByDegree(static_cast<Degree>(i));
    }

    std::cout << "Removing Student with ID A3: " << std::endl;
    roster.removeStudentByID("A3");
    std::cout << std::endl;
    
    std::cout << "Displaying all students: " << std::endl;
    roster.printAll();
    std::cout << std::endl;

    std::cout << "Removing student with ID A3: " << std::endl;
    roster.removeStudentByID("A3");
    std::cout << std::endl;
    
    roster.~Roster();
    std::cout << std::endl;

#ifdef _WIN32
    std::cout << "Press any key to continue..." << std::endl;
    _getch(); // Use _getch() to wait for a key press on Windows
#else
    std::cout << "Press Enter to continue..." << std::endl;
    std::cin.get(); // Use std::cin.get() to wait for Enter on other platforms
#endif

    return 0;
}

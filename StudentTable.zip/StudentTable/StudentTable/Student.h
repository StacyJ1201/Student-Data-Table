//
//  student.hpp
//  StudentTable
//
//  Created by Stacy Jones on 10/5/23.
//

#ifndef Student_h
#define Student_h
#define Student_h
#pragma once
#include <iostream>
#include <iomanip>
#include "Degree.h"
using std::string;
using std::cout;

class Student
{
public:
    const static int courseArraySize = 3;
public:
    string studentID;
    string firstName;
    string lastName;
    string email;
    double age;
    double courses[courseArraySize];
    Degree degree;
    
public:
    Student();
    Student(string studentID, string firstName, string lastName, string email, double age, double courses[], Degree degree);
    ~Student();

    //getters
    string getID();
    string getfirstName();
    string getlastName();
    string getEmail();
    double getAge();
    double* getCourses();
    Degree getDegree();

    //setters
    void setID(string ID);
    void setfirstName(string firstName);
    void setlastName(string lastName);
    void setEmail(string email);
    void setAge(double age);
    void setCourses(double courses[]);
    void setDegree(Degree dg);

    static void printHeader(); //display header

    void print(); //display data


};


#endif 

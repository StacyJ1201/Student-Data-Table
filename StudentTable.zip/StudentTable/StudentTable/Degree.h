//
//  degree.h
//  StudentTable
//
//  Created by Stacy Jones on 10/5/23.
//
#ifndef DEGREE_H_
#define DEGREE_H_
#pragma once
#include <string>
enum Degree { SECURITY, NETWORK, SOFTWARE };

    static const std::string degreeStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };




#endif

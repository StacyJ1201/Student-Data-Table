//
//  roster.cpp
//  StudentTable
//
//  Created by Stacy Jones on 10/5/23.
//

#include "Roster.h"
#include <iostream>
#include <string>

void Roster::parse(std::string studentData)
{
    Degree dg = SECURITY;

    if (studentData.find("NETWORK") != std::string::npos) {
        dg = NETWORK;
    } else if (studentData.find("SOFTWARE") != std::string::npos) {
        dg = SOFTWARE;
    }

    int rhs = studentData.find(",");
    std::string sID = studentData.substr(0, rhs);

    int lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    std::string fna = studentData.substr(lhs, rhs - lhs);

    lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    std::string lna = studentData.substr(lhs, rhs - lhs);

    lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    std::string ema = studentData.substr(lhs, rhs - lhs);

    lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    double ag;
    try {
        ag = stod(studentData.substr(lhs, rhs - lhs));
    } catch (const std::invalid_argument& e) {
        // Handle the error, such as setting a default value or skipping the record
        std::cerr << "Error parsing age: " << e.what() << std::endl;
        ag = 0.0; // Set a default value
    }

    lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    double d1;
    try {
        d1 = stod(studentData.substr(lhs, rhs - lhs));
    } catch (const std::invalid_argument& e) {
        // Handle the error, such as setting a default value or skipping the record
        std::cerr << "Error parsing d1: " << e.what() << std::endl;
        d1 = 0.0; // Set a default value
    }

    lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    double d2;
    try {
        d2 = stod(studentData.substr(lhs, rhs - lhs));
    } catch (const std::invalid_argument& e) {
        // Handle the error, such as setting a default value or skipping the record
        std::cerr << "Error parsing d2: " << e.what() << std::endl;
        d2 = 0.0; // Set a default value
    }

    lhs = rhs + 1;
    rhs = studentData.find(",", lhs);
    double d3;
    try {
        d3 = stod(studentData.substr(lhs, rhs - lhs));
    } catch (const std::invalid_argument& e) {
        // Handle the error, such as setting a default value or skipping the record
        std::cerr << "Error parsing d3: " << e.what() << std::endl;
        d3 = 0.0; // Set a default value
    }

    add(sID, fna, lna, ema, ag, d1, d2, d3, dg); // Add 'dg' as a parameter here
}

void Roster::add(std::string studentID, std::string firstName, std::string lastName, string email, double age, double day1, double day2, double day3, Degree dg)
{
    double carr[3] = { day1, day2, day3 };
    classRosterArray[++lastIndex] = new Student(studentID, firstName, lastName, email, age, carr, dg);
}

void Roster::printAll()
{
    Student::printHeader();
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        std::cout << classRosterArray[i]->getID() << "\t";
        std::cout << "First Name: " << classRosterArray[i]->getfirstName() << "\t";
        std::cout << "Last Name: "<< classRosterArray[i]->getlastName() << "\t";
        std::cout << "Email: "<< classRosterArray[i]->getEmail() << "\t";
        std::cout << "Age: "<< classRosterArray[i]->getAge() << "\t";
        std::cout << "Days in course: ";
        const double* courses = classRosterArray[i]->getCourses(); // Assuming getCourses() returns an array or pointer
        for (int j = 0; j < 3; j++)
        {
            std::cout << courses[j] << "\t";
        }
        std::cout << "Degree Program: "<< degreeStrings[classRosterArray[i]->getDegree()] << std::endl;
    }
}

/* display only books which match given book type*/
void Roster::printByDegree(Degree dg)
{
    Student::printHeader();
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        if (Roster::classRosterArray[i]->getDegree() == dg) classRosterArray[i]->print();
    }
    std::cout << std::endl;
}

// Each student email must contain an @ and a . with no space
void Roster::printInvalidEmails()
{
    bool any = false;
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        std::string sEmail = (classRosterArray[i]->getEmail());
        if (!(sEmail.find('@') != std::string::npos && sEmail.find('.') != std::string::npos && sEmail.find(' ') == std::string::npos))
        {
            any = true;
            std::cout << sEmail << ": " << classRosterArray[i]->getAge() << std::endl;
        }
    }
    if (!any) std::cout << "NONE" << std::endl;
}

double Roster::calculateAverageDays(std::string studentID) {
    double studentAverage = 0.0;
    
    for (int i = 0; i <= Roster::lastIndex; i++) {
        if (classRosterArray[i]->getID() == studentID) {
            studentAverage = (classRosterArray[i]->getCourses()[0] + classRosterArray[i]->getCourses()[1] + classRosterArray[i]->getCourses()[2]) / 3.0;
            return studentAverage;
        }
    }
    
    // Return a negative value to indicate that the student with the provided ID was not found.
    return -1.0;
}

void Roster::printAverageDays(std::string studentID) {
    for (int i = 0; i <= Roster::lastIndex; i++) {
        if (classRosterArray[i]->getID() == studentID) {
            std::cout << "Student ID " << studentID << " Average: ";
            std::cout << (classRosterArray[i]->getCourses()[0] + classRosterArray[i]->getCourses()[1] + classRosterArray[i]->getCourses()[2]) / 3.0 << std::endl;
            return; // Exit the function after printing the average for the student.
        }
    }
    
    std::cout << "Student ID " << studentID << " not found in the roster." << std::endl;
}

void Roster::removeStudentByID(std::string studentID)
{
    bool success = false;
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        if (classRosterArray[i]->getID() == studentID)
        {
            success = true;
            if (i < numStudents - 1)
            {
                Student* temp = classRosterArray[i];
                classRosterArray[i] = classRosterArray[numStudents - 1];
                classRosterArray[numStudents - 1] = temp;
            }
            Roster::lastIndex--;
        }
    }
    if (success)
    {
        std::cout << studentID << " removed from table." << std::endl << std::endl;
    }
    else std::cout << studentID << " not found." << std::endl << std::endl;
}

Roster::~Roster()
{
    std::cout << "DESTRUCTOR CALLED!!!" << std::endl << std::endl;
    for (int i = 0; i < numStudents; i++)
    {
        std::cout << "Destroying student #" << i + 1 << std::endl;
        delete classRosterArray[i];
        classRosterArray[i] = nullptr;
    }
}

//
//  student.cpp
//  StudentTable
//
//  Created by Stacy Jones on 10/5/23.
//

#include "Student.h"
#include <iostream> // Include the iostream library for cout

// Define the default constructor
Student::Student()
{
    this->studentID = "";
    this->firstName = "";
    this->lastName = "";
    this->email = "";
    this->age = 0;
    for (int i = 0; i < courseArraySize; i++) this->courses[i] = 0.0;
    this->degree = Degree::SECURITY;
}

// Define the parameterized constructor
Student::Student(string studentID, string firstName, string lastName, string  email, double age, double courses[], Degree degree)
{
    this->studentID = studentID;
    this->firstName = firstName;
    this->lastName = lastName;
    this->email = email;
    this->age = age;
    for (int i = 0; i < courseArraySize; i++) this->courses[i] = courses[i];
    this->degree = degree;
}

// Define the destructor
Student::~Student() {}

string Student::getID() { return this->studentID; }
string Student::getfirstName() { return this->firstName; }
string Student::getlastName() { return this->lastName; }
string Student::getEmail() { return this->email; }
double Student::getAge() { return this->age; }
double* Student::getCourses() { return this->courses; }
Degree Student::getDegree() { return this->degree; }

// Define the setPrices function
// Implementation of the setPrices function
void Student::setID(string ID) { this->studentID = ID; }
void Student::setfirstName(string firstName){ this->firstName = firstName; }
void Student::setlastName(string lastName) { this->lastName = lastName; }
void Student::setEmail(string email) {this->email = email;}
void Student::setAge(double age) {this->age = age;}
void Student::setCourses(double *courses)
{
    for (int i = 0; i < courseArraySize; i++) 
    {
        this->courses[i] = courses[i];
    }
}

// Define the setBookType function
void Student::setDegree(Degree dg) { this->degree = dg; }

void Student::printHeader()
{
    cout << "Output format: ID|First_Name|Last_Name|Email|Age|Days_in_Course|Degree_Program\n";
}

void Student::print()
{
    cout << this->getID() << '\t';
    cout << this->getfirstName() << '\t';
    cout << this->getlastName() << '\t';
    cout << this->getEmail() << '\t';
    cout << this->getAge() << '\t';
    cout << this->getCourses()[0] << ',';
    cout << this->getCourses()[1] << ',';
    cout << this->getCourses()[2] << ',';
    cout << degreeStrings[this->getDegree()] << '\n';
}

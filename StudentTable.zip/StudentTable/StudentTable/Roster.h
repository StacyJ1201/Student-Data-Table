//
//  roster.hpp
//  StudentTable
//
//  Created by Stacy Jones on 10/5/23.
//

#ifndef roster_h
#define roster_h
#include <stdio.h>
#pragma once
#include "Student.h"
class Roster
{
public:
    int lastIndex = -1;
    const static int numStudents = 5;
    Student* classRosterArray[numStudents];
    
public:
    
    void parse(string row);
    void add(string sID,
             string sfirstName,
             string slastName,
             string sEmail,
             double age,
             double scourse1,
             double scourse2,
             double scourse3,
             Degree dg);
    
    double calculateAverageDays(string studentID); // Function prototype declaration

    void printAll();
    void printByDegree(Degree dg);
    void printInvalidEmails();
    void printAverageDays(string studentID);
    void removeStudentByID(string studentID);
    ~Roster();
};

#endif /* roster_h */
